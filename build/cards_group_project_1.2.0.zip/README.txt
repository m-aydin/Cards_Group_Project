# Cards Group Project 1.2.0

## Program Instructions:
1.Run cards_group_project.py

2.Thats it

# Cards Group Project Credits:


## Project Manager:
Mert


## data_gen.py Contributors:
Arda, For gen_suit()

Suheed, For gen_suit_hands()

Reyan, For gen_face_vals()

Mohammed, For gen_hand_vals()

## data_proc.py Contributors:
Reyan, For add_card_vals()

Arda, For count_face_vals()


## ui.py Contributors:
Mohammed, For display_hand()

Suheed, For count_suits()

Mert, For list_cleaner()


## Cards Group Project Core Contributors:
Mert, For Organising File Structure, And For Laying Framework
